package com.example.tic_tac_toe_game

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
